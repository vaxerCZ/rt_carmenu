Config = {}

-- Main key for opening (Default: M)
-- List of keys: https://docs.fivem.net/docs/game-references/controls/
Config.OpenKey = 244

-- Command to console / chat
Config.Command = 'carmenu'

-- Default theme (choose key from Config.Themes)
Config.Theme = 'blue'

-- All translations (Edit menu texts here)
Config.Translate = {
    header_title = "RTZUS CARMENU CONTROL",
    plate_label = "Vehicle: ",
    footer_text = "Press [ESC] to close",
    back = "Back",
    
    -- Main menu
    engine = "Engine", 
    engine_desc = "Starts or stops the vehicle engine",
    
    trunk = "Trunk", 
    trunk_desc = "Opens / Closes the storage space",
    
    hood = "Hood", 
    hood_desc = "Accesses the engine compartment",
    
    doors = "Doors", 
    doors_desc = "Control individual doors",
    
    windows = "Windows", 
    windows_desc = "Rolling down and up windows",
    
    -- Sub-menu Doors
    door_0 = "Driver's door",
    door_1 = "Passenger's door",
    door_2 = "Rear left door",
    door_3 = "Rear right door",
    
    -- Sub-menu Windows
    win_0 = "Driver's window",
    win_1 = "Passenger's window",
    win_2 = "Rear left window",
    win_3 = "Rear right window",

    -- Notifications
    not_in_veh = "You must be inside a vehicle!",
    not_driver = "You must be in the driver's seat!"
}

-- Barevná témata pro banner
Config.Themes = {
    ['red'] = '#e74c3c',
    ['blue'] = '#3498db',
    ['green'] = '#2ecc71',
    ['yellow'] = '#f1c40f',
    ['purple'] = '#9b59b6',
    ['pink'] = '#fd79a8',
    ['orange'] = '#e67e22',
    ['teal'] = '#1abc9c',
    ['cyan'] = '#00d2d3',
    ['lime'] = '#badc58',
    ['indigo'] = '#3f51b5',
    ['amber'] = '#ffc107',
    ['brown'] = '#795548',
    ['grey'] = '#636e72',
    ['deep_orange'] = '#ff5722',
    ['gold'] = '#d4af37',
    ['silver'] = '#bdc3c7',
    ['black'] = '#1a1a1a',
    ['navy'] = '#0a3d62',
    ['violet'] = '#82589F'
}
