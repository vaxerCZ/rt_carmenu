-- Helper function for splitting text
local function SplitString(inputstr, sep)
    if sep == nil then sep = "%s" end
    local t = {}
    for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
        table.insert(t, str)
    end
    return t
end

-- Command registration
RegisterCommand(Config.Command, function()
    local playerPed = PlayerPedId()
    local veh = GetVehiclePedIsIn(playerPed, false)
    
    if veh ~= 0 then
        -- Check if driver (optional, but recommended)
        if GetPedInVehicleSeat(veh, -1) == playerPed then
            SetNuiFocus(true, true)
            SendNUIMessage({
                action = "open",
                plate = GetVehicleNumberPlateText(veh),
                theme = Config.Themes[Config.Theme] or '#3498db',
                trans = Config.Translate
            })
        else
            lib.notify({ title = 'Menu', description = Config.Translate.not_driver, type = 'error' })
        end
    else
        lib.notify({ title = 'Menu', description = Config.Translate.not_in_veh, type = 'error' })
    end
end, false)

-- Key detection
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if IsControlJustPressed(0, Config.OpenKey) then
            ExecuteCommand(Config.Command)
        end
    end
end)

-- NUI Callbacks
RegisterNUICallback('action', function(data, cb)
    local playerPed = PlayerPedId()
    local veh = GetVehiclePedIsIn(playerPed, false)
    
    if veh == 0 then return cb('error') end

    if data.id == "engine" then
        local status = GetIsVehicleEngineRunning(veh)
        SetVehicleEngineOn(veh, not status, false, true)
    
    elseif data.id == "trunk" then
        ToggleDoor(veh, 5)
    
    elseif data.id == "hood" then
        ToggleDoor(veh, 4)
    
    elseif string.find(data.id, "door_") then
        local parts = SplitString(data.id, "_")
        local doorIndex = tonumber(parts[2])
        ToggleDoor(veh, doorIndex)
    
    elseif string.find(data.id, "win_") then
        local parts = SplitString(data.id, "_")
        local winIndex = tonumber(parts[2])
        if IsVehicleWindowIntact(veh, winIndex) then
            RollDownWindow(veh, winIndex)
        else
            RollUpWindow(veh, winIndex)
        end
    end
    
    cb('ok')
end)

-- Door logic
function ToggleDoor(veh, id)
    if GetVehicleDoorAngleRatio(veh, id) > 0 then
        SetVehicleDoorShut(veh, id, false)
    else
        SetVehicleDoorOpen(veh, id, false, false)
    end
end

-- Menu closing
RegisterNUICallback('close', function(_, cb)
    SetNuiFocus(false, false)
    cb('ok')
end)
