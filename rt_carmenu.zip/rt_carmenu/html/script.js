let translations = {};

window.addEventListener('message', (event) => {
    const data = event.data;

    if (data.action === "open") {
        translations = data.trans;
        
        // Setting colors and texts from Config
        document.documentElement.style.setProperty('--accent', data.theme);
        document.getElementById('banner').style.background = data.theme;
        document.getElementById('plate-badge').innerText = data.plate;
        
        // Localization of UI elements
        document.getElementById('ui-title').innerText = translations.header_title;
        document.getElementById('ui-plate-label').innerText = translations.plate_label;
        document.getElementById('ui-footer').innerText = translations.footer_text;

        renderMenu("main");
        document.getElementById('app').style.display = 'flex';
    }
});

function renderMenu(menuType) {
    const container = document.getElementById('items-grid');
    container.innerHTML = "";
    let items = [];

    if (menuType === "main") {
        items = [
            { id: 'engine', title: translations.engine, desc: translations.engine_desc, icon: 'fa-bolt' },
            { id: 'trunk', title: translations.trunk, desc: translations.trunk_desc, icon: 'fa-box-open' },
            { id: 'hood', title: translations.hood, desc: translations.hood_desc, icon: 'fa-car-battery' },
            { id: 'doors', title: translations.doors, desc: translations.doors_desc, icon: 'fa-door-open', isSub: true },
            { id: 'windows', title: translations.windows, desc: translations.windows_desc, icon: 'fa-window-maximize', isSub: true }
        ];
    } else if (menuType === "doors") {
        items = [
            { id: 'main', title: translations.back, desc: '', icon: 'fa-arrow-left', isSub: true },
            { id: 'door_0', title: translations.door_0, desc: '', icon: 'fa-door-closed' },
            { id: 'door_1', title: translations.door_1, desc: '', icon: 'fa-door-closed' },
            { id: 'door_2', title: translations.door_2, desc: '', icon: 'fa-door-closed' },
            { id: 'door_3', title: translations.door_3, desc: '', icon: 'fa-door-closed' }
        ];
    } else if (menuType === "windows") {
        items = [
            { id: 'main', title: translations.back, desc: '', icon: 'fa-arrow-left', isSub: true },
            { id: 'win_0', title: translations.win_0, desc: '', icon: 'fa-window-restore' },
            { id: 'win_1', title: translations.win_1, desc: '', icon: 'fa-window-restore' },
            { id: 'win_2', title: translations.win_2, desc: '', icon: 'fa-window-restore' },
            { id: 'win_3', title: translations.win_3, desc: '', icon: 'fa-window-restore' }
        ];
    }

    items.forEach(item => {
        const card = document.createElement('div');
        card.className = 'card';
        card.innerHTML = `
            <div class="card-icon">
                <i class="fas ${item.icon}"></i>
            </div>
            <div class="info">
                <h2>${item.title}</h2>
                <p>${item.desc}</p>
            </div>
        `;

        card.onclick = () => {
            if (item.isSub) {
                renderMenu(item.id);
            } else {
                fetch(`https://${GetParentResourceName()}/action`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: item.id })
                });
            }
        };

        container.appendChild(card);
    });
}

// Closing on ESC
document.onkeyup = (e) => {
    if (e.key === "Escape") {
        const app = document.getElementById('app');
        app.classList.add('fade-out');
        app.addEventListener('animationend', () => {
            app.style.display = 'none';
            app.classList.remove('fade-out');
            fetch(`https://${GetParentResourceName()}/close`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({})
            });
        }, { once: true });
    }
};
