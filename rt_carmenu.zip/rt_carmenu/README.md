# Advanced NUI Car Control

Professional vehicle control menu with modern NUI interface for FiveM.

## Features
- Complete control (Engine, Trunk, Hood, Doors, Windows)
- Fully configurable colors (20+ preset themes)
- Translations directly in `config.lua` (no external files)
- Modern dark design with large header
- Display of vehicle license plate directly in the menu
- Responsive and animated interface

## Requirements
- `ox_lib` (for notifications)
- FiveM Server Build 2189 or newer

## Installation
1. Download the files and place them in the `resources/advanced_carcontrol` folder.
2. Add `ensure advanced_carcontrol` to your `server.cfg`.
3. Restart the server or start the resource.

## Configuration
- Open `config.lua` to change the key (default F10), command or banner color.
- All menu texts can be found in the `Config.Translate` section.

## Controls
- **F10**: Open menu (can be changed in config)
- **ESC**: Close menu
- **Click**: Perform action or open sub-menu
