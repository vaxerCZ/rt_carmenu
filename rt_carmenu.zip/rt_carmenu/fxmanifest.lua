fx_version 'cerulean'
game 'gta5'

description 'Advanced NUI Car Control Menu'
version '1.0.0'

ui_page 'html/index.html'

client_script 'client.lua'
shared_script 'config.lua'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}

dependencies {
    'ox_lib'
}
